
import random

class Tile(object):
    def __init__(self):
        pass
    
    def __str__(self):
        return "?"
    
    def reveal(self):
        return False
    
    def toggleFlag(self):
        pass

    def increaseNeighbors(self):
        pass

class Minesweeper(object):
    def __init__(self, size=4, mines=2):
        self.size = size
        self.mines = mines
        self.totalFlags = 0
        
        # stub setup for the board
        self.board = [["?" for col in range(self.size)] for row in range(self.size)]
    
    def minesRemaining(self):
        return 0
 
    def isExploded(self):
        return False
       
    def isGameOver(self):
        return False
 
    def flag(self, row, column):
        pass
    
    def step(self, row, column):
        pass
        
    def showAll(self):
        pass
    
    def getAt(self, row, column):
        return "?"
 
    def isKnown(self, row, column):
        return False
    
    def __len__(self):
        return 10
             
       

      
      